package com.community.weare.Repositories;

import org.springframework.stereotype.Repository;

@Repository
public interface SexRepository {
}
