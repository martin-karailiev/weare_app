package com.community.weare.Models;

public enum Sex {
    MALE,FEMALE;
}
